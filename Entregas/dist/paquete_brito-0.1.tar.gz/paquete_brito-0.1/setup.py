from setuptools import setup
Version = '0.1'
Description = 'Modelamiento de Clientes en una página de compras'
Author = 'Andrea Brito'

setup(
    name='Paquete_Brito',
    version=Version,
    description=Description,
    author=Author,
    packages=['Paquete_Brito']
)